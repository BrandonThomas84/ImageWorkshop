<?php
/**
 * stirling_grand.php
 *
 * @package stirling_grand
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: stirling_grand.php 2 2013-09-03 Picaflor Azul $
 */

define('BOX_CONFIGURATION_STIRLING_GRAND', 'Stirling Grand');