<div id="home-text">
<p>
This content is located in the file at: /languages/english/html_includes/stirling_grand/define_main_page.php
</p>
<p>
You can quickly edit this content via Admin->Tools->Define Pages Editor, and select define_main_page from the pulldown.
</p>
</div>		