<?php
/**
 * @package Pages
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: about_us.php v1.3 $
 */

// About Us Filename Defines
  define('FILENAME_ABOUT_US', 'about_us');
  define('FILENAME_DEFINE_ABOUT_US', 'define_about_us');
?>